"use strict";
var support_ticket_datatable = {
    init: function() {
    	$('#basic-6').DataTable();
    }
};
jQuery(document).ready(function() {
    support_ticket_datatable.init()
});
